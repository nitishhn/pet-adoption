package com.hexaware.exception;

public class InsufficientFundsException extends Exception{
	public InsufficientFundsException(String text) {
        super(text);
    }
}