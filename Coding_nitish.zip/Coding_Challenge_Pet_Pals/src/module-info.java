/**
 * 
 */
/**
 * @author navne
 *
 */
module Coding_Challenge_Pet_Pals {
	requires java.sql;
}